<?php 
//Sessão
session_start();
//conexão
require_once 'db_connect.php';
//Clear 
function clear($input){
	global $connect;
	//sql
	$var = mysqli_escape_string($connect, $input);
	//xss
	$var = htmlspecialchars($var);
	return $var;
}

if (isset($_POST['btn-cadastrar'])) {

	/* antes da função clear
	$nome = mysqli_escape_string($connect, $_POST['nome']);
	$sobrenome = mysqli_escape_string($connect, $_POST['sobrenome']);
	$email = mysqli_escape_string($connect, $_POST['email']);
	$idade = mysqli_escape_string($connect, $_POST['idade']);
	*/
	// depois da função clear()
	$nome = clear($_POST['nome']);
	$sobrenome = clear($_POST['sobrenome']);
	$email = clear($_POST['email']);
	$idade = clear($_POST['idade']);

	$sql = "INSERT INTO clientes (nome, sobrenome, email, idade) VALUES ('$nome', '$sobrenome', '$email', '$idade')";


	    if (mysqli_query($connect, $sql)) {
	    	$_SESSION['mensagem'] = "Cadastrado com Sucesso!";
	    	header('Location: ../index.php');
	    }else{
	    	$_SESSION['mensagem'] = "Erro ao Cadastrar!";	
	    	header('Location: ../index.php');
	    	//echo("Error description: " . mysqli_error($connect));
	    }

}
