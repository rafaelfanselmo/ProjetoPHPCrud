<?php 
//Sessão
session_start();
//conexão
require_once 'db_connect.php';
//Clear 
function clear($input){
	global $connect;
	//sql
	$var = mysqli_escape_string($connect, $input);
	//xss
	$var = htmlspecialchars($var);
	return $var;
}

if (isset($_POST['btn-editar'])) {

	/* Anstes da função clear()
	$id = mysqli_escape_string($connect, $_POST['id']);
	$nome = mysqli_escape_string($connect, $_POST['nome']);
	$sobrenome = mysqli_escape_string($connect, $_POST['sobrenome']);
	$email = mysqli_escape_string($connect, $_POST['email']);
	$idade = mysqli_escape_string($connect, $_POST['idade']);
	*/
	// depois da função clear
	$id = clear($_POST['id']);
	$nome = clear($_POST['nome']);
	$sobrenome = clear($_POST['sobrenome']);
	$email = clear($_POST['email']);
	$idade = clear($_POST['idade']);

	$sql = "UPDATE clientes SET nome='$nome', sobrenome='$sobrenome', email='$email', idade='$idade' WHERE id = '$id' ";


	    if (mysqli_query($connect, $sql)) {
	    	$_SESSION['mensagem'] = "Atualizado com Sucesso!";
	    	header('Location: ../index.php');
	    }else{
	    	$_SESSION['mensagem'] = "Erro ao Atualizar!";	
	    	header('Location: ../index.php');
	    	//echo("Error description: " . mysqli_error($connect));
	    }

}
