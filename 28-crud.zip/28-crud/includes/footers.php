            
      <!--JavaScript at end of body for optimized loading-->
      <!-- utilizando link abaixo
      <script type="text/javascript" src="js/materialize.min.js"></script>
       -->


      <!-- Compiled and minified JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

    <script >
          M.AutoInit();
    </script>
    </body>
  </html>